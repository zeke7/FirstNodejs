// UserController.js
//it will contain the actions which control the flow of data into and from your database.
var express = require('express');
var router = express.Router();		//using the express router
var bodyParser = require('body-parser');

router.use(bodyParser.urlencoded({ extended: true }));		// The body-parser module is used as a middleware to handle data in a more elegant way.
var User = require('./User');

// ADD THIS PART

// CREATES A NEW USER
router.post('/', function (req, res) {

    User.create({
            name : req.body.name,
            email : req.body.email,
            password : req.body.password
        }, 
        function (err, user) {
            if (err) return res.status(500).send("There was a problem adding the information to the database.");
            res.status(200).send(user);
        });

});

// RETURNS ALL THE USERS IN THE DATABASE
router.get('/', function (req, res) {

    User.find({}, function (err, users) {
        if (err) return res.status(500).send("There was a problem finding the users.");
        res.status(200).send(users);
    });

});

// Deletes a user from the database
router.delete('/:id', function(req, res){
	User.findByIdAndRemove(req.params.id, function(err, user){
		if(err) return res.status(500).send("There was a problem deleting the user.");	
		res.status(200).send("User "+ user.name+"was deleted.");
	});	

});


// Updates a single user in the database
router.put('/:id', function(req, res){
	
	User.findByIdAndUpdate(req.params.id, req.body,{new:true}, 
function(err, user){
	if(err) return res.status(500).send("There was a problem updating the user.");
	res.status(200).send(user);
	});
});








	

module.exports = router;
