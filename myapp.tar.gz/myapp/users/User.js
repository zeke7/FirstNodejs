// User.js
// user folder will contain all files in any way related to our communication with the database regarding users. 

//a user model      a blueprint showing what all users in your database will look like
var mongoose = require('mongoose');  
var UserSchema = new mongoose.Schema({  //creating a schema which will give every user in the database a specific look.
  name: String,
  email: String,
  password: String
});
mongoose.model('User', UserSchema); // binding the layout of the schema to the model which is named 'User'

module.exports = mongoose.model('User');     //to access the data in the database
