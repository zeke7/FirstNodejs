// server.js
// Tell the app where to listen
// Spinning up the node server on a specific port of your choice

var app = require('./app');// require app ==> variable
var port = process.env.PORT || 27017;//choosing a port for the app to run on

var server = app.listen(port, function() {   //spin up the server with app.listen
  console.log('Express server listening on port ' + port);
});
