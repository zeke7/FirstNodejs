var mongoose = require('mongoose'); 
var db = mongoose.connect('mongodb://hfangapi:ni12wo34@creating-node-api-shard-00-00-broyp.mongodb.net:27017,creating-node-api-shard-00-01-broyp.mongodb.net:27017,creating-node-api-shard-00-02-broyp.mongodb.net:27017/test?ssl=true&replicaSet=creating-node-api-shard-0&authSource=admin',{
	useMongoClient: true,
	keepAlive:true,
	reconnectTries:30
}); 





