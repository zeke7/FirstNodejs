// app.js
// configuring the application


var express = require('express');
var app = express();
var db = require('./db');


var UserController = require('./users/UserController');
app.use('/users', UserController);//telling the app to link it to the route /users

module.exports = app;// module.exports make this app object visible 
